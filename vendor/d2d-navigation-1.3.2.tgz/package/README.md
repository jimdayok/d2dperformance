# Shared D2D website chrome
Canonical source: index.jsx and styles.css. Version 1.2.0 provides the same header and footer across Marketing, Digital and Performance. Division adapters supply the logo, navigation links, contact action and theme.

The division strip keeps Client Login at the top on desktop and mobile. Header contact actions remain visible on desktop and inside the mobile menu. Footer structure, contact details, company links, legal links and social accounts are shared; YouTube and TikTok are non-clickable Coming soon items.

Compile JSX to ESM with React external using esbuild, npm pack, and install exactly the same archive in every site. Verify all three divisions together on desktop/mobile, including inner pages, native-dialog focus and scroll restoration, Client Login dismissal and non-clickable pending socials. D2DDivisionSelector remains available for standalone microsites.
