# Shared D2D navigation

Canonical source is index.jsx and styles.css. Package 1.1.3 restores desktop links, keeps MENU for overflow/mobile, shares the division icon selector, and uses a bundled Alata font. Header backgrounds are 72% opaque so content remains visible while scrolling. Transparent padding in the Digital/Performance logo PNGs is compensated in CSS; the visible artwork width matches Marketing.

Edit here, compile JSX to ESM with React external using esbuild, bump version, npm pack, and install the same archive into every website vendor directory. Rebuild and review all three together. Division adapters supply content and theme only. D2DDivisionSelector also serves the Cart Convoy microsite without replacing its own navigation. Native dialog, explicit tab wrapping, immediate scroll restoration before anchor navigation, focus restoration, reduced motion, touch support and Escape/outside dismissal are shared.
