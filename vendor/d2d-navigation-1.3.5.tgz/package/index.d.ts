import type {ReactElement} from 'react';
type Link={href:string;label:string};
export function D2DNavigation(props:{division:'marketing'|'digital'|'performance';logo:string;links:readonly Link[];cta:Link;clientLinks?:readonly Link[]}):ReactElement;

export function D2DDivisionSelector(props:{division?:'marketing'|'digital'|'performance';showClientLogin?:boolean}):ReactElement;

export function D2DFooter(props:{division:"marketing"|"digital"|"performance";logo:string}):ReactElement;
