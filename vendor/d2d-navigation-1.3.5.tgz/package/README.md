# Shared D2D website chrome

One header and footer for Marketing, Digital and Performance. Compact right-aligned division tabs, top Client Login, visible primary links across screen sizes, and division contact CTA. No overflow MENU. Digital leads with websites; Performance leads with digital tools. Social accounts without a verified URL remain unlinked, with no status label.
