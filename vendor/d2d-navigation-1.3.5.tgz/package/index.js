"use client";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useRef, useEffect, useId } from "react";
const divisions = [{ id: "marketing", label: "D2D Marketing", href: "https://d2dmktg.com" }, { id: "digital", label: "D2D Digital", href: "https://digital.d2dmktg.com" }, { id: "performance", label: "D2D Performance", href: "https://performance.d2dmktg.com" }];
function DivisionIcon({ id }) {
  const paths = id === "marketing" ? /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("path", { d: "m3 11 18-5v12L3 14z" }),
    /* @__PURE__ */ jsx("path", { d: "m7 15 2 6h3l-2-5M21 6V3m0 15v3" })
  ] }) : id === "digital" ? /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx("path", { d: "m7 6-5 6 5 6m10-12 5 6-5 6m-3-15-4 18" }) }) : /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx("path", { d: "M3 21V13m6 8V9m6 12v-7m6 7V3M3 8l6-5 6 6 6-8" }) });
  return /* @__PURE__ */ jsx("svg", { viewBox: "0 0 24 24", width: "21", height: "21", fill: "none", stroke: "currentColor", strokeWidth: "1.6", strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", children: paths });
}
const defaultClientLinks = [
  { href: "https://webadmin.d2dmktg.com/portal/login", label: "D2D Site Manager" },
  { href: "https://brandvault.d2dmktg.com/auth/login", label: "D2D Brand Vault" },
  { href: "https://social.d2dperformance.com/login", label: "D2D Social Pages" }
];
function D2DDivisionSelector({ division = "marketing", clientLinks = defaultClientLinks, clientMenu, showClientLogin = true, mobileMenu }) {
  return /* @__PURE__ */ jsx("nav", { className: "d2dn d2dn-companies d2dn-" + division + (showClientLogin ? "" : " d2dn-no-client") + (mobileMenu ? " d2dn-has-menu" : ""), "aria-label": "D2D companies", children: /* @__PURE__ */ jsxs("div", { className: "d2dn-top-inner", children: [
    /* @__PURE__ */ jsx("div", { className: "d2dn-division-links", children: divisions.map((d) => /* @__PURE__ */ jsxs("a", { href: d.id === division ? "/" : d.href, "aria-label": d.label, "aria-current": d.id === division ? "true" : void 0, children: [
      /* @__PURE__ */ jsx(DivisionIcon, { id: d.id }),
      /* @__PURE__ */ jsxs("strong", { children: [
        /* @__PURE__ */ jsx("span", { className: "d2dn-company-prefix", children: "D2D " }),
        d.label.replace("D2D ", "")
      ] })
    ] }, d.id)) }),
    (showClientLogin || mobileMenu) && /* @__PURE__ */ jsxs("div", { className: "d2dn-utility", children: [
      /* @__PURE__ */ jsx("span", { className: "d2dn-mobile-note", children: "One connected D2D" }),
      showClientLogin && /* @__PURE__ */ jsxs("details", { ref: clientMenu, className: "d2dn-client-dropdown", children: [
        /* @__PURE__ */ jsx("summary", { children: "Client Login" }),
        /* @__PURE__ */ jsx("nav", { "aria-label": "Client login options", children: clientLinks.map((l) => /* @__PURE__ */ jsxs("a", { href: l.href, children: [
          l.label,
          /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "\u2197" })
        ] }, l.label)) })
      ] }),
      mobileMenu
    ] })
  ] }) });
}
function Logo({ logo, label, panel = false }) {
  return /* @__PURE__ */ jsx("span", { className: `d2dn-logo-art${panel ? " d2dn-panel-logo" : ""}`, children: /* @__PURE__ */ jsx("img", { src: logo, alt: label, width: "491", height: "142" }) });
}
function D2DNavigation({ division, logo, links, cta, clientLinks = defaultClientLinks }) {
  const header = useRef(null), clientMenu = useRef(null), shell = useRef(null), dialog = useRef(null), trigger = useRef(null), restore = useRef(null);
  const dialogId = useId();
  function cleanup() {
    trigger.current?.setAttribute("aria-expanded", "false");
    if (restore.current) {
      restore.current();
      restore.current = null;
    }
    trigger.current?.focus({ preventScroll: true });
  }
  function close() {
    dialog.current?.close();
  }
  function open() {
    if (!dialog.current || dialog.current.open) return;
    if (clientMenu.current) clientMenu.current.open = false;
    const y = window.scrollY, body = document.body;
    const saved = { position: body.style.position, top: body.style.top, width: body.style.width, overflow: body.style.overflow };
    restore.current = () => {
      Object.assign(body.style, saved);
      const html = document.documentElement, b = html.style.scrollBehavior;
      html.style.scrollBehavior = "auto";
      window.scrollTo(0, y);
      html.style.scrollBehavior = b;
    };
    body.style.position = "fixed";
    body.style.top = `-${y}px`;
    body.style.width = "100%";
    body.style.overflow = "hidden";
    dialog.current.showModal();
    trigger.current?.setAttribute("aria-expanded", "true");
  }
  function trap(e) {
    if (e.key !== "Tab") return;
    const nodes = [...dialog.current.querySelectorAll("a[href],button:not([disabled])")], first = nodes[0], last = nodes[nodes.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }
  useEffect(() => {
    const desktop = window.matchMedia("(min-width:900px)");
    const resize = () => {
      if (desktop.matches && dialog.current?.open) dialog.current.close();
    };
    desktop.addEventListener("change", resize);
    return () => {
      desktop.removeEventListener("change", resize);
      restore.current?.();
    };
  }, []);
  useEffect(() => {
    const update = () => {
      if (restore.current) return;
      header.current?.classList.toggle("is-scrolled", window.scrollY > 24);
      shell.current?.classList.toggle("is-mobile-scrolled", window.scrollY > 100);
      if (window.scrollY > 100 && window.matchMedia("(max-width:899px)").matches && clientMenu.current) clientMenu.current.open = false;
    };
    const dismiss = (e) => {
      if (e.key === "Escape" && clientMenu.current?.open) {
        clientMenu.current.open = false;
        clientMenu.current.querySelector("summary")?.focus();
      }
    };
    const outside = (e) => {
      if (clientMenu.current?.open && !clientMenu.current.contains(e.target)) clientMenu.current.open = false;
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
    document.addEventListener("keydown", dismiss);
    document.addEventListener("pointerdown", outside);
    return () => {
      window.removeEventListener("scroll", update);
      document.removeEventListener("keydown", dismiss);
      document.removeEventListener("pointerdown", outside);
    };
  }, []);
  const current = divisions.find((d) => d.id === division);
  return /* @__PURE__ */ jsxs("div", { ref: shell, className: "d2dn d2dn-shell d2dn-" + division, children: [
    /* @__PURE__ */ jsx(D2DDivisionSelector, { division, clientLinks, clientMenu, mobileMenu: /* @__PURE__ */ jsxs("button", { ref: trigger, type: "button", className: "d2dn-mobile-trigger d2dn-trigger", onClick: open, "aria-label": "Open menu", "aria-expanded": "false", "aria-haspopup": "dialog", "aria-controls": dialogId, children: [
      /* @__PURE__ */ jsx("span", { className: "d2dn-menu-label", children: "Menu" }),
      /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "\u2630" })
    ] }) }),
    /* @__PURE__ */ jsx("header", { ref: header, className: "d2dn-header", children: /* @__PURE__ */ jsxs("div", { className: "d2dn-header-inner", children: [
      /* @__PURE__ */ jsx("a", { className: "d2dn-logo", href: "/", "aria-label": current.label + " home", children: /* @__PURE__ */ jsx(Logo, { logo, label: current.label }) }),
      /* @__PURE__ */ jsx("nav", { className: "d2dn-desktop", "aria-label": "Primary navigation", children: links.map((l) => /* @__PURE__ */ jsx("a", { href: l.href, children: l.label }, l.label)) }),
      /* @__PURE__ */ jsx("div", { className: "d2dn-actions", children: /* @__PURE__ */ jsxs("a", { className: "d2dn-header-cta", href: cta.href, children: [
        cta.label,
        " ",
        /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "\u2197" })
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsxs("dialog", { ref: dialog, id: dialogId, className: "d2dn-dialog d2dn-" + division, "aria-label": current.label + " menu", onClose: cleanup, onKeyDown: trap, onClick: (e) => {
      if (e.target === e.currentTarget) {
        const r = e.currentTarget.getBoundingClientRect();
        if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) close();
      }
    }, children: [
      /* @__PURE__ */ jsxs("div", { className: "d2dn-panel-top", children: [
        /* @__PURE__ */ jsx(Logo, { logo, label: current.label, panel: true }),
        /* @__PURE__ */ jsxs("button", { type: "button", autoFocus: true, className: "d2dn-close", onClick: close, "aria-label": "Close menu", children: [
          "Close ",
          /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "\xD7" })
        ] })
      ] }),
      /* @__PURE__ */ jsx("nav", { className: "d2dn-links", "aria-label": "Mobile navigation", children: links.map((l) => /* @__PURE__ */ jsxs("a", { href: l.href, onClick: close, children: [
        l.label,
        /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "\u2197" })
      ] }, l.label)) }),
      /* @__PURE__ */ jsxs("a", { className: "d2dn-cta", href: cta.href, onClick: close, children: [
        cta.label,
        /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "\u2197" })
      ] }),
      /* @__PURE__ */ jsxs("nav", { className: "d2dn-client", "aria-label": "Client Login", children: [
        /* @__PURE__ */ jsx("h2", { children: "Client Login" }),
        clientLinks.map((l) => /* @__PURE__ */ jsxs("a", { href: l.href, onClick: close, children: [
          l.label,
          /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "\u2197" })
        ] }, l.label))
      ] }),
      /* @__PURE__ */ jsxs("nav", { className: "d2dn-explore", "aria-label": "Explore D2D", children: [
        /* @__PURE__ */ jsx("p", { children: "Explore D2D" }),
        divisions.map((d) => /* @__PURE__ */ jsxs("a", { href: d.id === division ? "/" : d.href, onClick: close, children: [
          /* @__PURE__ */ jsx(DivisionIcon, { id: d.id }),
          d.label
        ] }, d.id))
      ] })
    ] })
  ] });
}
function SocialIcon({ name }) {
  const paths = {
    Facebook: /* @__PURE__ */ jsx("path", { d: "M14 22v-9h3l.5-4H14V7c0-1.2.3-2 2-2h2V1.5A24 24 0 0 0 15 1c-3 0-5 1.8-5 5v3H7v4h3v9z" }),
    Instagram: /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("rect", { x: "3", y: "3", width: "18", height: "18", rx: "5", fill: "none", stroke: "currentColor", strokeWidth: "1.8" }),
      /* @__PURE__ */ jsx("circle", { cx: "12", cy: "12", r: "4", fill: "none", stroke: "currentColor", strokeWidth: "1.8" }),
      /* @__PURE__ */ jsx("circle", { cx: "17.5", cy: "6.5", r: "1.2" })
    ] }),
    LinkedIn: /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("path", { d: "M4 9h4v13H4zM10 9h4v2c1-2 7-4 7 4v7h-4v-7c0-3-3-3-3 0v7h-4z" }),
      /* @__PURE__ */ jsx("circle", { cx: "6", cy: "4.5", r: "2.2" })
    ] }),
    YouTube: /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("path", { d: "M22 7c-.2-2-1-3-3-3H5C3 4 2 5 2 7v10c0 2 1 3 3 3h14c2 0 3-1 3-3z", fill: "none", stroke: "currentColor", strokeWidth: "1.7" }),
      /* @__PURE__ */ jsx("path", { d: "m10 8 6 4-6 4z" })
    ] }),
    TikTok: /* @__PURE__ */ jsx("path", { d: "M15 2h3c.2 3 1.8 4.8 4 5v3a9 9 0 0 1-4-1v8a6 6 0 1 1-6-6v3a3 3 0 1 0 3 3z" })
  };
  return /* @__PURE__ */ jsx("svg", { viewBox: "0 0 24 24", width: "20", height: "20", fill: "currentColor", "aria-hidden": "true", children: paths[name] });
}
const socialAccounts = [
  { name: "Facebook", href: "https://www.facebook.com/day2daymktg2016" },
  { name: "Instagram", href: "https://www.instagram.com/day2daymarketing/" },
  { name: "LinkedIn", href: "https://linkedin.com/in/mckinneymarketingandreaday" },
  { name: "YouTube" },
  { name: "TikTok" }
];
function D2DFooter({ division, logo }) {
  const current = divisions.find((d) => d.id === division);
  return /* @__PURE__ */ jsx("footer", { className: "d2df d2dn-" + division, children: /* @__PURE__ */ jsxs("div", { className: "d2df-inner", children: [
    /* @__PURE__ */ jsxs("div", { className: "d2df-heading", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("span", { className: "d2df-eyebrow", children: "ONE BUSINESS. THREE CONNECTED DISCIPLINES." }),
        /* @__PURE__ */ jsxs("h2", { children: [
          "Clarity. Capability.",
          /* @__PURE__ */ jsx("br", {}),
          /* @__PURE__ */ jsx("em", { children: "Forward momentum." })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("a", { className: "d2df-contact", href: "https://d2dmktg.com/contact", children: [
        "Let\u2019s build what\u2019s next ",
        /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "\u2197" })
      ] })
    ] }),
    /* @__PURE__ */ jsx("nav", { className: "d2df-divisions", "aria-label": "Explore the D2D family", children: divisions.map((d) => /* @__PURE__ */ jsxs("a", { href: d.href, children: [
      /* @__PURE__ */ jsx(DivisionIcon, { id: d.id }),
      /* @__PURE__ */ jsx("strong", { children: d.label }),
      /* @__PURE__ */ jsx("span", { children: d.id === "marketing" ? "Brand strategy & marketing" : d.id === "digital" ? "Website design & development" : "Digital tools & connected systems" }),
      /* @__PURE__ */ jsx("b", { "aria-hidden": "true", children: "\u2197" })
    ] }, d.id)) }),
    /* @__PURE__ */ jsxs("div", { className: "d2df-grid", children: [
      /* @__PURE__ */ jsxs("div", { className: "d2df-brand", children: [
        /* @__PURE__ */ jsx("a", { href: current.href, "aria-label": current.label + " home", children: /* @__PURE__ */ jsx(Logo, { logo, label: current.label }) }),
        /* @__PURE__ */ jsx("p", { children: "One team connecting your brand, your systems and the way your business moves forward." }),
        /* @__PURE__ */ jsxs("p", { className: "d2df-location", children: [
          "North Texas roots.",
          /* @__PURE__ */ jsx("br", {}),
          "Clients coast to coast."
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "d2df-column", children: [
        /* @__PURE__ */ jsx("h3", { children: "Start a conversation" }),
        /* @__PURE__ */ jsx("a", { href: "mailto:info@d2dmktg.com", children: "info@d2dmktg.com" }),
        /* @__PURE__ */ jsx("a", { href: "tel:+12697887067", children: "269-788-7067" }),
        /* @__PURE__ */ jsxs("p", { children: [
          "207 E Virginia Street, Suite 205",
          /* @__PURE__ */ jsx("br", {}),
          "McKinney, TX 75069"
        ] }),
        /* @__PURE__ */ jsx("a", { href: "https://d2dmktg.com/schedule-meeting", children: "Book a conversation \u2197" })
      ] }),
      /* @__PURE__ */ jsxs("nav", { className: "d2df-column", "aria-label": "Company information", children: [
        /* @__PURE__ */ jsx("h3", { children: "Keep exploring" }),
        /* @__PURE__ */ jsx("a", { href: "https://d2dmktg.com/why-d2d", children: "About D2D" }),
        /* @__PURE__ */ jsx("a", { href: "https://d2dmktg.com/services", children: "Our services" }),
        /* @__PURE__ */ jsx("a", { href: "https://d2dmktg.com/field-notes", children: "Field Notes" }),
        /* @__PURE__ */ jsx("a", { href: "https://d2dmktg.com/better-together", children: "Better together" }),
        /* @__PURE__ */ jsx("a", { href: "https://d2dmktg.com/sign-up-for-our-newsletter", children: "Join the newsletter \u2197" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "d2df-column d2df-social", children: [
        /* @__PURE__ */ jsx("h3", { children: "Follow the DAY2DAY" }),
        /* @__PURE__ */ jsx("p", { children: "Ideas, work and what\u2019s next." }),
        /* @__PURE__ */ jsx("div", { className: "d2df-social-links", children: socialAccounts.map((s) => s.href ? /* @__PURE__ */ jsxs("a", { href: s.href, target: "_blank", rel: "noopener noreferrer", "aria-label": s.name + " \u2014 opens in a new tab", children: [
          /* @__PURE__ */ jsx(SocialIcon, { name: s.name }),
          /* @__PURE__ */ jsx("span", { children: s.name })
        ] }, s.name) : /* @__PURE__ */ jsxs("span", { className: "d2df-social-pending", "aria-disabled": "true", "aria-label": s.name, children: [
          /* @__PURE__ */ jsx(SocialIcon, { name: s.name }),
          /* @__PURE__ */ jsx("span", { children: s.name })
        ] }, s.name)) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "d2df-bottom", children: [
      /* @__PURE__ */ jsxs("span", { children: [
        "\xA9 ",
        (/* @__PURE__ */ new Date()).getFullYear(),
        " DAY2DAY. Built for the work ahead."
      ] }),
      /* @__PURE__ */ jsxs("nav", { "aria-label": "Legal information", children: [
        /* @__PURE__ */ jsx("a", { href: "https://d2dmktg.com/privacy-policy", children: "Privacy" }),
        /* @__PURE__ */ jsx("a", { href: "https://d2dmktg.com/terms-of-use", children: "Terms" }),
        /* @__PURE__ */ jsx("a", { href: "https://d2dmktg.com/accessibility", children: "Accessibility" })
      ] }),
      /* @__PURE__ */ jsx("a", { href: "https://digital.d2dmktg.com", children: "Designed & built by D2D Digital \u2197" })
    ] })
  ] }) });
}
export {
  D2DDivisionSelector,
  D2DFooter,
  D2DNavigation
};
